
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/SignupServlet"})
public class SignupServlet extends HttpServlet {


  
    

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/jsp");
            PrintWriter out = response.getWriter();
        
           String fullname = request.getParameter("fullname");
           String email = request.getParameter("email");
           String password = request.getParameter("password");
           String confirmpassword = request.getParameter("confirmpassword");
          
            
        try{
                Class.forName("com.mysql.jdbc.Driver");
               
                Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/digital","root","");
                
                
                System.out.println("Connected");
                
                String sql="INSERT INTO `registration`(fullname,email,password, confirmpassword) VALUES (?,?,?,?)";
                
                PreparedStatement pre = con.prepareStatement(sql);
               
                pre.setString(1, fullname);                
                pre.setString(2, email);
                pre.setString(3, password);
                pre.setString(4, confirmpassword);
                
                pre.executeUpdate();
                
                RequestDispatcher redi = request.getRequestDispatcher("login.jsp");
                
                redi.forward(request, response);
                
                con.close();




        
        
        
        }
        catch(Exception e){
        System.out.println("Error"+e.getMessage());
        }
    }

  

}
