/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2_java;

import java.util.regex.*;

public class MasterClass {
    public boolean checkEmail(String email)
    {
        if(!Pattern.matches("[a-zA-Z0-9._]{1,30}[@][a-zA-Z]{1,10}[.][a-zA-Z]{1,6}",email))
        {
           return false; 
        }
        return true;
    }
    public int getStringLength(String txt)
    {
      return txt.length();  
    }
    public String changeToUpper(String txt)
    {
        txt=txt.toUpperCase();
        return txt;
    }
    public boolean checkPassword(String password)
    {
        if(!Pattern.matches("[A-Z]{8,12}", password))
        {
            return false;
        }
        return true;
    }
}
